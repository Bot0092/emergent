"""Coupon item/category restrictions + usage endpoint tests.

Covers:
- CouponCreate accepts applies_to_categories[] / applies_to_items[]
- GET /api/coupons returns those fields on each coupon doc
- POST /api/coupons/validate with items[]: restricted coupons require items,
  reject when no eligible items, and discount only from eligible subtotal
- Percent restricted with max_discount cap
- Mixed cart: only eligible portion is discounted
- POST /api/orders honors restrictions, stores coupon_code + discount, increments used_count
- GET /api/coupons/{code}/usage: admin only, 404 for unknown, returns
  {code, used_count, total_discount_given, orders[]} with expected fields
"""
import os
import pytest
import requests

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL", "").rstrip("/")
API = f"{BASE_URL}/api"

ADMIN_H = {"Authorization": "Bearer TEST_ADMIN_TOKEN_001", "Content-Type": "application/json"}
CUST_H = {"Authorization": "Bearer TEST_CUSTOMER_TOKEN_001", "Content-Type": "application/json"}

CREATED_CODES: list[str] = []


@pytest.fixture(scope="module")
def s():
    return requests.Session()


@pytest.fixture(scope="module", autouse=True)
def cleanup():
    yield
    sess = requests.Session()
    for code in CREATED_CODES + [
        "TRES_CATBURG", "TRES_ITEMONE", "TRES_PCTCAP", "TRES_MIX",
        "TRES_NOELIG", "TRES_USAGE", "TRES_EMPTY",
    ]:
        try:
            sess.delete(f"{API}/coupons/{code}", headers=ADMIN_H, timeout=5)
        except Exception:
            pass


# Module-level menu cache populated lazily inside fixtures
@pytest.fixture(scope="module")
def menu(s):
    r = s.get(f"{API}/menu", timeout=10)
    assert r.status_code == 200, r.text
    items = r.json()
    assert items, "menu seed is empty"
    return items


@pytest.fixture(scope="module")
def cats_by_count(menu):
    # category -> list of items
    by = {}
    for it in menu:
        by.setdefault(it["category"], []).append(it)
    # pick a category with at least 1 item and another category for non-eligible items
    sorted_cats = sorted(by.items(), key=lambda kv: -len(kv[1]))
    assert len(sorted_cats) >= 2, "need >=2 categories"
    return sorted_cats


# ---------- Create with restrictions ----------
class TestCreateWithRestrictions:
    def test_create_category_restricted(self, s, cats_by_count):
        cat = cats_by_count[0][0]
        payload = {
            "code": "TRES_CATBURG",
            "discount_type": "flat",
            "value": 30,
            "min_order": 0,
            "active": True,
            "applies_to_categories": [cat],
        }
        r = s.post(f"{API}/coupons", headers=ADMIN_H, json=payload)
        assert r.status_code == 200, r.text
        d = r.json()
        assert d["applies_to_categories"] == [cat]
        assert d["applies_to_items"] == []
        CREATED_CODES.append("TRES_CATBURG")

    def test_create_item_restricted(self, s, menu):
        item_id = menu[0]["id"]
        payload = {
            "code": "TRES_ITEMONE",
            "discount_type": "percent",
            "value": 20,
            "applies_to_items": [item_id],
        }
        r = s.post(f"{API}/coupons", headers=ADMIN_H, json=payload)
        assert r.status_code == 200, r.text
        d = r.json()
        assert d["applies_to_items"] == [item_id]
        assert d["applies_to_categories"] == []
        CREATED_CODES.append("TRES_ITEMONE")

    def test_list_returns_new_fields(self, s):
        r = s.get(f"{API}/coupons", headers=ADMIN_H)
        assert r.status_code == 200
        lst = r.json()
        for d in lst:
            assert "applies_to_categories" in d
            assert "applies_to_items" in d
            assert isinstance(d["applies_to_categories"], list)
            assert isinstance(d["applies_to_items"], list)


# ---------- Validate restrictions ----------
class TestValidateRestrictions:
    def test_restricted_requires_items(self, s):
        # No items[] passed -> 400
        r = s.post(f"{API}/coupons/validate", headers=CUST_H,
                   json={"code": "TRES_CATBURG", "subtotal": 500})
        assert r.status_code == 400

    def test_no_eligible_items_rejected(self, s, cats_by_count, menu):
        # Use a coupon restricted to cat[0] but pass items from cat[1]
        target_cat = cats_by_count[0][0]
        # find an item NOT in target_cat
        other_item = next(it for it in menu if it["category"] != target_cat)
        payload = {
            "code": "TRES_CATBURG",
            "subtotal": 500,
            "items": [{"item_id": other_item["id"], "price": 250, "quantity": 2}],
        }
        r = s.post(f"{API}/coupons/validate", headers=CUST_H, json=payload)
        assert r.status_code == 400
        assert "doesn't apply" in r.text.lower() or "doesnt apply" in r.text.lower() or "doesn" in r.text.lower()

    def test_eligible_items_apply(self, s, cats_by_count):
        target_cat, items_in_cat = cats_by_count[0]
        elig = items_in_cat[0]
        payload = {
            "code": "TRES_CATBURG",
            "subtotal": 400,
            "items": [{"item_id": elig["id"], "price": 200, "quantity": 2}],
        }
        r = s.post(f"{API}/coupons/validate", headers=CUST_H, json=payload)
        assert r.status_code == 200, r.text
        # Flat 30 off, eligible subtotal=400, discount=30
        assert r.json()["discount"] == 30.0

    def test_mixed_cart_only_eligible_portion(self, s, menu, cats_by_count):
        # Create a percent coupon (10%) restricted to a single item
        elig_item = cats_by_count[0][1][0]
        other_item = next(it for it in menu if it["category"] != cats_by_count[0][0])
        s.post(f"{API}/coupons", headers=ADMIN_H, json={
            "code": "TRES_MIX",
            "discount_type": "percent",
            "value": 10,
            "applies_to_items": [elig_item["id"]],
        })
        CREATED_CODES.append("TRES_MIX")
        # cart: 2x eligible @ 200 + 3x other @ 100 = 400 + 300 = 700; eligible_subtotal=400; discount=40
        payload = {
            "code": "TRES_MIX",
            "subtotal": 700,
            "items": [
                {"item_id": elig_item["id"], "price": 200, "quantity": 2},
                {"item_id": other_item["id"], "price": 100, "quantity": 3},
            ],
        }
        r = s.post(f"{API}/coupons/validate", headers=CUST_H, json=payload)
        assert r.status_code == 200, r.text
        assert r.json()["discount"] == 40.0

    def test_percent_restricted_with_max_discount_cap(self, s, menu):
        elig_item = menu[0]
        s.post(f"{API}/coupons", headers=ADMIN_H, json={
            "code": "TRES_PCTCAP",
            "discount_type": "percent",
            "value": 50,
            "max_discount": 25,
            "applies_to_items": [elig_item["id"]],
        })
        CREATED_CODES.append("TRES_PCTCAP")
        # 50% of 400 = 200 -> capped to 25
        payload = {
            "code": "TRES_PCTCAP",
            "subtotal": 400,
            "items": [{"item_id": elig_item["id"], "price": 200, "quantity": 2}],
        }
        r = s.post(f"{API}/coupons/validate", headers=CUST_H, json=payload)
        assert r.status_code == 200, r.text
        assert r.json()["discount"] == 25.0


# ---------- Order integration with restrictions ----------
class TestOrderWithRestrictions:
    def test_order_no_eligible_rejected(self, s, cats_by_count, menu):
        other_item = next(it for it in menu if it["category"] != cats_by_count[0][0])
        payload = {
            "items": [{"item_id": other_item["id"], "name": other_item["name"],
                       "price": 100, "quantity": 2}],
            "order_type": "takeaway",
            "coupon_code": "TRES_CATBURG",
        }
        r = s.post(f"{API}/orders", headers=CUST_H, json=payload)
        assert r.status_code == 400

    def test_order_eligible_applies_discount(self, s, cats_by_count):
        elig = cats_by_count[0][1][0]
        payload = {
            "items": [{"item_id": elig["id"], "name": elig["name"],
                       "price": 150, "quantity": 2}],
            "order_type": "takeaway",
            "coupon_code": "TRES_CATBURG",
        }
        r = s.post(f"{API}/orders", headers=CUST_H, json=payload)
        assert r.status_code == 200, r.text
        d = r.json()
        assert d["subtotal"] == 300
        assert d["discount"] == 30
        assert d["total"] == 270
        assert d["coupon_code"] == "TRES_CATBURG"

    def test_order_mixed_cart_discount_only_eligible(self, s, menu, cats_by_count):
        elig_item = cats_by_count[0][1][0]
        other = next(it for it in menu if it["category"] != cats_by_count[0][0])
        # Use TRES_MIX (10% on elig_item only) - same elig_item as validate test
        # If cats_by_count[0][1][0] differs from prior test, the coupon is item-specific
        # we wired TRES_MIX to elig_item -> matches first item of largest category
        payload = {
            "items": [
                {"item_id": elig_item["id"], "name": elig_item["name"], "price": 200, "quantity": 2},
                {"item_id": other["id"], "name": other["name"], "price": 100, "quantity": 3},
            ],
            "order_type": "takeaway",
            "coupon_code": "TRES_MIX",
        }
        r = s.post(f"{API}/orders", headers=CUST_H, json=payload)
        assert r.status_code == 200, r.text
        d = r.json()
        assert d["subtotal"] == 700
        assert d["discount"] == 40  # only 400 eligible @ 10%
        assert d["total"] == 660


# ---------- Usage endpoint ----------
class TestCouponUsageEndpoint:
    def test_usage_admin_only(self, s):
        s.post(f"{API}/coupons", headers=ADMIN_H, json={
            "code": "TRES_USAGE",
            "discount_type": "flat",
            "value": 20,
        })
        CREATED_CODES.append("TRES_USAGE")
        # Unauthed
        r1 = s.get(f"{API}/coupons/TRES_USAGE/usage")
        assert r1.status_code == 401
        # Customer
        r2 = s.get(f"{API}/coupons/TRES_USAGE/usage", headers=CUST_H)
        assert r2.status_code == 403
        # Admin OK
        r3 = s.get(f"{API}/coupons/TRES_USAGE/usage", headers=ADMIN_H)
        assert r3.status_code == 200

    def test_usage_unknown_returns_404(self, s):
        r = s.get(f"{API}/coupons/NEVER_USED_XYZ/usage", headers=ADMIN_H)
        assert r.status_code == 404

    def test_usage_empty_coupon_returns_zero(self, s):
        s.post(f"{API}/coupons", headers=ADMIN_H, json={
            "code": "TRES_EMPTY",
            "discount_type": "flat",
            "value": 5,
        })
        CREATED_CODES.append("TRES_EMPTY")
        r = s.get(f"{API}/coupons/TRES_EMPTY/usage", headers=ADMIN_H)
        assert r.status_code == 200, r.text
        d = r.json()
        assert d["code"] == "TRES_EMPTY"
        assert d["used_count"] == 0
        assert d["total_discount_given"] == 0
        assert d["orders"] == []

    def test_usage_after_orders(self, s):
        # Place 2 orders with TRES_USAGE (no restrictions) -> used_count=2, total_discount=40
        for _ in range(2):
            r = s.post(f"{API}/orders", headers=CUST_H, json={
                "items": [{"item_id": "i1", "name": "TEST_Item",
                           "price": 100, "quantity": 2}],
                "order_type": "takeaway",
                "coupon_code": "TRES_USAGE",
            })
            assert r.status_code == 200, r.text
        r = s.get(f"{API}/coupons/TRES_USAGE/usage", headers=ADMIN_H)
        assert r.status_code == 200, r.text
        d = r.json()
        assert d["code"] == "TRES_USAGE"
        assert d["used_count"] >= 2
        assert d["total_discount_given"] >= 40.0
        assert len(d["orders"]) >= 2
        sample = d["orders"][0]
        for k in ("id", "user_name", "user_email", "discount", "total",
                  "order_type", "status", "created_at"):
            assert k in sample, f"missing key {k} in usage order entry"
        assert sample["discount"] == 20.0
        assert sample["order_type"] == "takeaway"
