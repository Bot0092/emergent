"""Coupons + Offers feature backend tests.

Covers:
- GET /api/coupons admin-only
- POST /api/coupons with all validation rules (code format, value, percent cap, min_order, duplicate)
- PUT /api/coupons/{code}/toggle flips active
- DELETE /api/coupons/{code} removes
- POST /api/coupons/validate
- POST /api/orders accepts coupon_code, applies discount, total math correct,
  coupons.used_count atomically incremented
- Percent max_discount cap & flat-not-exceeding-subtotal behaviour
"""
import os
import pytest
import requests

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL", "").rstrip("/")
API = f"{BASE_URL}/api"

ADMIN_TOKEN = "TEST_ADMIN_TOKEN_001"
CUSTOMER_TOKEN = "TEST_CUSTOMER_TOKEN_001"

ADMIN_H = {"Authorization": f"Bearer {ADMIN_TOKEN}", "Content-Type": "application/json"}
CUST_H = {"Authorization": f"Bearer {CUSTOMER_TOKEN}", "Content-Type": "application/json"}

# Track codes created for cleanup
CREATED_CODES: list[str] = []


@pytest.fixture(scope="module")
def s():
    return requests.Session()


@pytest.fixture(scope="module", autouse=True)
def cleanup():
    """Pre+post-cleanup: wipe TEST_-prefixed coupons via DELETE."""
    yield
    sess = requests.Session()
    for code in CREATED_CODES + ["TEST_FLAT50", "TEST_PCT10", "TEST_PCTCAP", "TEST_MIN500",
                                  "TEST_DUP", "TEST_TOGGLE", "TEST_DEL", "TEST_USEDCNT",
                                  "TEST_FLATBIG", "TEST_INACTIVE"]:
        try:
            sess.delete(f"{API}/coupons/{code}", headers=ADMIN_H, timeout=5)
        except Exception:
            pass


# ---------- Auth / list ----------
class TestCouponsAuth:
    def test_list_requires_auth(self, s):
        r = s.get(f"{API}/coupons")
        assert r.status_code == 401

    def test_list_forbidden_for_customer(self, s):
        r = s.get(f"{API}/coupons", headers=CUST_H)
        assert r.status_code == 403

    def test_list_admin_ok(self, s):
        r = s.get(f"{API}/coupons", headers=ADMIN_H)
        assert r.status_code == 200
        assert isinstance(r.json(), list)

    def test_create_forbidden_for_customer(self, s):
        r = s.post(f"{API}/coupons", headers=CUST_H,
                   json={"code": "TEST_NOAUTH", "discount_type": "flat", "value": 10})
        assert r.status_code == 403


# ---------- Create validation ----------
class TestCouponCreateValidation:
    def test_create_flat_ok(self, s):
        payload = {"code": "test_flat50", "discount_type": "flat", "value": 50,
                   "min_order": 200, "active": True}
        r = s.post(f"{API}/coupons", headers=ADMIN_H, json=payload)
        assert r.status_code == 200, r.text
        d = r.json()
        # Code uppercased
        assert d["code"] == "TEST_FLAT50"
        assert d["discount_type"] == "flat"
        assert d["value"] == 50.0
        assert d["min_order"] == 200.0
        assert d["active"] is True
        assert d["used_count"] == 0
        CREATED_CODES.append("TEST_FLAT50")

    def test_create_percent_ok(self, s):
        r = s.post(f"{API}/coupons", headers=ADMIN_H,
                   json={"code": "TEST_PCT10", "discount_type": "percent", "value": 10})
        assert r.status_code == 200, r.text
        assert r.json()["discount_type"] == "percent"
        CREATED_CODES.append("TEST_PCT10")

    def test_duplicate_code_rejected(self, s):
        r = s.post(f"{API}/coupons", headers=ADMIN_H,
                   json={"code": "TEST_FLAT50", "discount_type": "flat", "value": 5})
        assert r.status_code == 400
        assert "exist" in r.text.lower()

    def test_invalid_code_chars(self, s):
        r = s.post(f"{API}/coupons", headers=ADMIN_H,
                   json={"code": "BAD CODE!", "discount_type": "flat", "value": 10})
        assert r.status_code == 400

    def test_empty_code_rejected(self, s):
        r = s.post(f"{API}/coupons", headers=ADMIN_H,
                   json={"code": "", "discount_type": "flat", "value": 10})
        assert r.status_code == 400

    def test_code_too_long(self, s):
        r = s.post(f"{API}/coupons", headers=ADMIN_H,
                   json={"code": "A" * 25, "discount_type": "flat", "value": 10})
        assert r.status_code == 400

    def test_zero_value_rejected(self, s):
        r = s.post(f"{API}/coupons", headers=ADMIN_H,
                   json={"code": "TEST_ZERO", "discount_type": "flat", "value": 0})
        assert r.status_code == 400

    def test_negative_value_rejected(self, s):
        r = s.post(f"{API}/coupons", headers=ADMIN_H,
                   json={"code": "TEST_NEG", "discount_type": "flat", "value": -5})
        assert r.status_code == 400

    def test_percent_over_100_rejected(self, s):
        r = s.post(f"{API}/coupons", headers=ADMIN_H,
                   json={"code": "TEST_PCT200", "discount_type": "percent", "value": 200})
        assert r.status_code == 400

    def test_min_order_negative_rejected(self, s):
        r = s.post(f"{API}/coupons", headers=ADMIN_H,
                   json={"code": "TEST_MINNEG", "discount_type": "flat", "value": 10,
                         "min_order": -1})
        assert r.status_code == 400

    def test_min_order_above_max_rejected(self, s):
        r = s.post(f"{API}/coupons", headers=ADMIN_H,
                   json={"code": "TEST_MINBIG", "discount_type": "flat", "value": 10,
                         "min_order": 100001})
        assert r.status_code == 400


# ---------- Toggle / Delete ----------
class TestToggleDelete:
    def test_toggle_flips_active(self, s):
        s.post(f"{API}/coupons", headers=ADMIN_H,
               json={"code": "TEST_TOGGLE", "discount_type": "flat", "value": 10, "active": True})
        CREATED_CODES.append("TEST_TOGGLE")
        r = s.put(f"{API}/coupons/TEST_TOGGLE/toggle", headers=ADMIN_H)
        assert r.status_code == 200, r.text
        assert r.json()["active"] is False
        # Toggle again
        r2 = s.put(f"{API}/coupons/TEST_TOGGLE/toggle", headers=ADMIN_H)
        assert r2.json()["active"] is True

    def test_toggle_lowercase_input(self, s):
        # Endpoint should normalize code to upper
        r = s.put(f"{API}/coupons/test_toggle/toggle", headers=ADMIN_H)
        assert r.status_code == 200

    def test_toggle_404(self, s):
        r = s.put(f"{API}/coupons/NOPE_NOT_REAL/toggle", headers=ADMIN_H)
        assert r.status_code == 404

    def test_delete_removes(self, s):
        s.post(f"{API}/coupons", headers=ADMIN_H,
               json={"code": "TEST_DEL", "discount_type": "flat", "value": 5})
        r = s.delete(f"{API}/coupons/TEST_DEL", headers=ADMIN_H)
        assert r.status_code == 200
        # Confirm gone from list
        lst = s.get(f"{API}/coupons", headers=ADMIN_H).json()
        codes = [c["code"] for c in lst]
        assert "TEST_DEL" not in codes

    def test_delete_404(self, s):
        r = s.delete(f"{API}/coupons/NOPE_NONE", headers=ADMIN_H)
        assert r.status_code == 404


# ---------- Validate ----------
class TestValidate:
    def test_validate_flat_ok(self, s):
        r = s.post(f"{API}/coupons/validate", headers=CUST_H,
                   json={"code": "TEST_FLAT50", "subtotal": 300})
        assert r.status_code == 200, r.text
        d = r.json()
        assert d["code"] == "TEST_FLAT50"
        assert d["discount"] == 50.0
        assert d["discount_type"] == "flat"
        assert d["min_order"] == 200.0

    def test_validate_percent_ok(self, s):
        r = s.post(f"{API}/coupons/validate", headers=CUST_H,
                   json={"code": "TEST_PCT10", "subtotal": 500})
        assert r.status_code == 200
        assert r.json()["discount"] == 50.0  # 10% of 500

    def test_validate_below_min_order(self, s):
        r = s.post(f"{API}/coupons/validate", headers=CUST_H,
                   json={"code": "TEST_FLAT50", "subtotal": 100})
        assert r.status_code == 400
        assert "min" in r.text.lower() or "more" in r.text.lower()

    def test_validate_invalid_code(self, s):
        r = s.post(f"{API}/coupons/validate", headers=CUST_H,
                   json={"code": "NEVER_EXISTED", "subtotal": 500})
        assert r.status_code == 400

    def test_validate_empty_code(self, s):
        r = s.post(f"{API}/coupons/validate", headers=CUST_H,
                   json={"code": "", "subtotal": 500})
        assert r.status_code == 400

    def test_validate_inactive_coupon(self, s):
        s.post(f"{API}/coupons", headers=ADMIN_H,
               json={"code": "TEST_INACTIVE", "discount_type": "flat", "value": 20,
                     "active": False})
        CREATED_CODES.append("TEST_INACTIVE")
        r = s.post(f"{API}/coupons/validate", headers=CUST_H,
                   json={"code": "TEST_INACTIVE", "subtotal": 500})
        assert r.status_code == 400
        assert "active" in r.text.lower() or "longer" in r.text.lower()

    def test_validate_requires_auth(self, s):
        r = s.post(f"{API}/coupons/validate",
                   json={"code": "TEST_FLAT50", "subtotal": 500})
        assert r.status_code == 401

    def test_validate_percent_with_max_discount_cap(self, s):
        s.post(f"{API}/coupons", headers=ADMIN_H,
               json={"code": "TEST_PCTCAP", "discount_type": "percent", "value": 50,
                     "max_discount": 30})
        CREATED_CODES.append("TEST_PCTCAP")
        # 50% of 200 = 100, but capped at 30
        r = s.post(f"{API}/coupons/validate", headers=CUST_H,
                   json={"code": "TEST_PCTCAP", "subtotal": 200})
        assert r.status_code == 200
        assert r.json()["discount"] == 30.0

    def test_validate_flat_never_exceeds_subtotal(self, s):
        s.post(f"{API}/coupons", headers=ADMIN_H,
               json={"code": "TEST_FLATBIG", "discount_type": "flat", "value": 10000})
        CREATED_CODES.append("TEST_FLATBIG")
        r = s.post(f"{API}/coupons/validate", headers=CUST_H,
                   json={"code": "TEST_FLATBIG", "subtotal": 250})
        assert r.status_code == 200
        # Discount capped at subtotal (250)
        assert r.json()["discount"] == 250.0


# ---------- Order integration ----------
class TestOrderWithCoupon:
    def test_order_no_coupon_works(self, s):
        payload = {
            "items": [{"item_id": "i1", "name": "TEST_Item", "price": 100, "quantity": 3}],
            "order_type": "takeaway",
        }
        r = s.post(f"{API}/orders", headers=CUST_H, json=payload)
        assert r.status_code == 200, r.text
        d = r.json()
        assert d["total"] == 300
        assert d.get("discount", 0) == 0
        assert d.get("coupon_code") in (None, "")

    def test_order_with_flat_coupon(self, s):
        payload = {
            "items": [{"item_id": "i1", "name": "TEST_Item", "price": 100, "quantity": 3}],
            "order_type": "takeaway",
            "coupon_code": "TEST_FLAT50",
        }
        r = s.post(f"{API}/orders", headers=CUST_H, json=payload)
        assert r.status_code == 200, r.text
        d = r.json()
        assert d["subtotal"] == 300
        assert d["discount"] == 50
        assert d["total"] == 250
        assert d["coupon_code"] == "TEST_FLAT50"

    def test_order_with_percent_coupon(self, s):
        payload = {
            "items": [{"item_id": "i1", "name": "TEST_Item", "price": 200, "quantity": 2}],
            "order_type": "takeaway",
            "coupon_code": "TEST_PCT10",
        }
        r = s.post(f"{API}/orders", headers=CUST_H, json=payload)
        assert r.status_code == 200, r.text
        d = r.json()
        assert d["subtotal"] == 400
        assert d["discount"] == 40
        assert d["total"] == 360

    def test_order_lowercase_coupon_normalized(self, s):
        payload = {
            "items": [{"item_id": "i1", "name": "TEST_Item", "price": 100, "quantity": 3}],
            "order_type": "takeaway",
            "coupon_code": "test_flat50",
        }
        r = s.post(f"{API}/orders", headers=CUST_H, json=payload)
        assert r.status_code == 200
        assert r.json()["coupon_code"] == "TEST_FLAT50"
        assert r.json()["discount"] == 50

    def test_order_with_invalid_coupon_rejected(self, s):
        payload = {
            "items": [{"item_id": "i1", "name": "TEST_Item", "price": 100, "quantity": 3}],
            "order_type": "takeaway",
            "coupon_code": "TOTALLY_FAKE",
        }
        r = s.post(f"{API}/orders", headers=CUST_H, json=payload)
        assert r.status_code == 400

    def test_order_below_min_order_rejected(self, s):
        payload = {
            "items": [{"item_id": "i1", "name": "TEST_Item", "price": 50, "quantity": 1}],
            "order_type": "takeaway",
            "coupon_code": "TEST_FLAT50",  # min 200
        }
        r = s.post(f"{API}/orders", headers=CUST_H, json=payload)
        assert r.status_code == 400

    def test_used_count_increments(self, s):
        # Create dedicated coupon, fetch initial used_count, place 2 orders, verify +2
        s.post(f"{API}/coupons", headers=ADMIN_H,
               json={"code": "TEST_USEDCNT", "discount_type": "flat", "value": 10})
        CREATED_CODES.append("TEST_USEDCNT")
        lst = s.get(f"{API}/coupons", headers=ADMIN_H).json()
        before = next(c for c in lst if c["code"] == "TEST_USEDCNT")["used_count"]
        for _ in range(2):
            r = s.post(f"{API}/orders", headers=CUST_H, json={
                "items": [{"item_id": "i1", "name": "TEST_Item", "price": 100, "quantity": 1}],
                "order_type": "takeaway",
                "coupon_code": "TEST_USEDCNT",
            })
            assert r.status_code == 200, r.text
        lst2 = s.get(f"{API}/coupons", headers=ADMIN_H).json()
        after = next(c for c in lst2 if c["code"] == "TEST_USEDCNT")["used_count"]
        assert after == before + 2, f"used_count expected {before+2}, got {after}"

    def test_order_with_inactive_coupon_rejected(self, s):
        payload = {
            "items": [{"item_id": "i1", "name": "TEST_Item", "price": 100, "quantity": 3}],
            "order_type": "takeaway",
            "coupon_code": "TEST_INACTIVE",
        }
        r = s.post(f"{API}/orders", headers=CUST_H, json=payload)
        assert r.status_code == 400
