"""Tests for the rating-display-with-items feature.

Verifies GET /api/ratings returns:
  - count, average
  - items[] with order_id, order_type, items[]{name, variant_label, quantity}
And that admin auth is required.
"""

import os
import pytest
import requests

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL", "https://order-brew-login.preview.emergentagent.com").rstrip("/")

ADMIN_TOKEN = "TEST_ADMIN_TOKEN_001"
CUSTOMER_TOKEN = "TEST_CUSTOMER_TOKEN_001"


@pytest.fixture
def admin_client():
    s = requests.Session()
    s.headers.update({"Authorization": f"Bearer {ADMIN_TOKEN}", "Content-Type": "application/json"})
    return s


@pytest.fixture
def customer_client():
    s = requests.Session()
    s.headers.update({"Authorization": f"Bearer {CUSTOMER_TOKEN}", "Content-Type": "application/json"})
    return s


# ---------- Auth gating ----------
class TestRatingsAuth:
    def test_unauthenticated_blocked(self):
        r = requests.get(f"{BASE_URL}/api/ratings")
        assert r.status_code in (401, 403)

    def test_customer_blocked(self, customer_client):
        r = customer_client.get(f"{BASE_URL}/api/ratings")
        assert r.status_code == 403


# ---------- Response shape ----------
class TestRatingsResponseShape:
    def test_admin_can_read(self, admin_client):
        r = admin_client.get(f"{BASE_URL}/api/ratings")
        assert r.status_code == 200
        body = r.json()
        assert "count" in body and "average" in body and "items" in body
        assert isinstance(body["items"], list)
        assert body["count"] == len(body["items"])

    def test_rating_objects_contain_items_and_order_type(self, admin_client):
        r = admin_client.get(f"{BASE_URL}/api/ratings")
        assert r.status_code == 200
        items = r.json()["items"]
        if not items:
            pytest.skip("No ratings present to validate shape")
        for rating in items:
            assert "order_id" in rating
            assert "rating" in rating and 1 <= int(rating["rating"]) <= 5
            assert "order_type" in rating  # may be null but key must exist
            assert "items" in rating and isinstance(rating["items"], list)
            for line in rating["items"]:
                assert "name" in line
                assert "variant_label" in line
                assert "quantity" in line
                assert isinstance(line["quantity"], int)

    def test_no_mongo_oid_leak(self, admin_client):
        body = admin_client.get(f"{BASE_URL}/api/ratings").json()
        for r in body.get("items", []):
            assert "_id" not in r
            for line in r.get("items", []):
                assert "_id" not in line


# ---------- Customer rating submission (regression) ----------
class TestRatingSubmissionRegression:
    """The customer rating submission flow must still work; we seed a completed
    order on the customer account and POST a rating."""

    def test_submit_rating_to_seeded_completed_order(self, customer_client, admin_client):
        # Pick any unrated completed order for the test customer
        my = customer_client.get(f"{BASE_URL}/api/orders/me")
        assert my.status_code == 200
        target = next((o for o in my.json() if o["status"] == "completed" and not o.get("rating") and o["id"].startswith("ord_TEST_RATE_")), None)
        if not target:
            pytest.skip("No seeded unrated completed order present")

        r = customer_client.post(
            f"{BASE_URL}/api/orders/{target['id']}/rating",
            json={"rating": 5, "comment": "TEST_AUTO regression"},
        )
        assert r.status_code == 200, r.text
        data = r.json()
        assert data["rating"] == 5
        assert data["rating_comment"] == "TEST_AUTO regression"

        # Now verify it shows up in /api/ratings with items[]
        ratings = admin_client.get(f"{BASE_URL}/api/ratings").json()
        match = next((x for x in ratings["items"] if x["order_id"] == target["id"]), None)
        assert match is not None
        assert len(match["items"]) >= 1
        assert match["items"][0]["name"]  # non-empty name
        assert match["order_type"] in ("takeaway", "dine-in", "delivery")

    def test_double_rate_rejected(self, customer_client):
        my = customer_client.get(f"{BASE_URL}/api/orders/me").json()
        already = next((o for o in my if o.get("rating")), None)
        if not already:
            pytest.skip("No already-rated order")
        r = customer_client.post(
            f"{BASE_URL}/api/orders/{already['id']}/rating",
            json={"rating": 3, "comment": "again"},
        )
        assert r.status_code == 400
