"""Backend API tests for The Crunchy Bite cafe app.

Covers:
- Health, menu, categories
- Auth (auth/me with bearer, 401 without)
- Orders CRUD (customer & admin)
- Admin-only endpoints (menu CRUD, orders list, stats, order status)
- Role enforcement (403 customer vs admin)
"""
import os
import pytest
import requests

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL", "https://order-brew-login.preview.emergentagent.com").rstrip("/")
API = f"{BASE_URL}/api"

# Seeded tokens (see mongosh seeding step in test harness)
ADMIN_TOKEN = "TEST_ADMIN_TOKEN_001"
CUSTOMER_TOKEN = "TEST_CUSTOMER_TOKEN_001"
ADMIN_EMAIL = "freefund804@gmail.com"
CUSTOMER_EMAIL = "test.customer@example.com"


@pytest.fixture(scope="module")
def s():
    sess = requests.Session()
    sess.headers.update({"Content-Type": "application/json"})
    return sess


@pytest.fixture(scope="module")
def admin_headers():
    return {"Authorization": f"Bearer {ADMIN_TOKEN}"}


@pytest.fixture(scope="module")
def customer_headers():
    return {"Authorization": f"Bearer {CUSTOMER_TOKEN}"}


# ---------- Health & catalog ----------
class TestCatalog:
    def test_root(self, s):
        r = s.get(f"{API}/")
        assert r.status_code == 200
        assert r.json().get("status") == "ok"

    def test_menu_count(self, s):
        r = s.get(f"{API}/menu")
        assert r.status_code == 200
        data = r.json()
        assert isinstance(data, list)
        assert len(data) == 145, f"Expected 145 menu items, got {len(data)}"
        # validate fields
        item = data[0]
        for k in ("id", "name", "category", "price"):
            assert k in item

    def test_categories_count(self, s):
        r = s.get(f"{API}/categories")
        assert r.status_code == 200
        data = r.json()
        assert isinstance(data, list)
        assert len(data) == 25, f"Expected 25 categories, got {len(data)}"
        for c in data:
            assert "slug" in c and "name" in c


# ---------- Auth ----------
class TestAuth:
    def test_me_without_auth_401(self, s):
        r = s.get(f"{API}/auth/me")
        assert r.status_code == 401

    def test_me_with_invalid_token_401(self, s):
        r = s.get(f"{API}/auth/me", headers={"Authorization": "Bearer not-a-real-token"})
        assert r.status_code == 401

    def test_me_admin_role(self, s, admin_headers):
        r = s.get(f"{API}/auth/me", headers=admin_headers)
        assert r.status_code == 200, r.text
        data = r.json()
        assert data["email"] == ADMIN_EMAIL
        assert data["role"] == "admin"

    def test_me_customer_role(self, s, customer_headers):
        r = s.get(f"{API}/auth/me", headers=customer_headers)
        assert r.status_code == 200, r.text
        data = r.json()
        assert data["email"] == CUSTOMER_EMAIL
        assert data["role"] == "customer"

    def test_session_bad_session_id(self, s):
        # /auth/session validates against emergent OAuth — fake id should 401
        r = s.post(f"{API}/auth/session", json={"session_id": "fake-invalid-session-id-xyz"})
        assert r.status_code == 401

    def test_session_missing_id(self, s):
        r = s.post(f"{API}/auth/session", json={})
        assert r.status_code == 400


# ---------- Orders ----------
class TestOrders:
    def test_orders_requires_auth(self, s):
        r = s.post(f"{API}/orders", json={"items": [], "order_type": "takeaway"})
        assert r.status_code == 401

    def test_order_empty_items_400(self, s, customer_headers):
        r = s.post(f"{API}/orders", headers=customer_headers,
                   json={"items": [], "order_type": "takeaway"})
        assert r.status_code == 400

    def test_order_dinein_no_table_400(self, s, customer_headers):
        payload = {
            "items": [{"item_id": "i1", "name": "Latte", "price": 200, "quantity": 1}],
            "order_type": "dine-in",
        }
        r = s.post(f"{API}/orders", headers=customer_headers, json=payload)
        assert r.status_code == 400

    def test_create_order_takeaway(self, s, customer_headers):
        payload = {
            "items": [
                {"item_id": "i1", "name": "TEST_Cappuccino", "price": 180, "quantity": 2},
                {"item_id": "i2", "name": "TEST_Croissant", "price": 120, "quantity": 1},
            ],
            "order_type": "takeaway",
            "notes": "TEST_order",
        }
        r = s.post(f"{API}/orders", headers=customer_headers, json=payload)
        assert r.status_code == 200, r.text
        data = r.json()
        assert data["total"] == 180 * 2 + 120
        assert data["status"] == "pending"
        assert data["user_email"] == CUSTOMER_EMAIL
        # store for next test
        pytest.created_order_id = data["id"]

    def test_orders_me_includes_created(self, s, customer_headers):
        r = s.get(f"{API}/orders/me", headers=customer_headers)
        assert r.status_code == 200
        ids = [o["id"] for o in r.json()]
        assert pytest.created_order_id in ids

    def test_orders_list_forbidden_for_customer(self, s, customer_headers):
        r = s.get(f"{API}/orders", headers=customer_headers)
        assert r.status_code == 403

    def test_orders_list_admin(self, s, admin_headers):
        r = s.get(f"{API}/orders", headers=admin_headers)
        assert r.status_code == 200
        assert isinstance(r.json(), list)

    def test_update_order_status_customer_forbidden(self, s, customer_headers):
        r = s.put(f"{API}/orders/{pytest.created_order_id}/status",
                  headers=customer_headers, json={"status": "preparing"})
        assert r.status_code == 403

    def test_update_order_status_admin(self, s, admin_headers):
        r = s.put(f"{API}/orders/{pytest.created_order_id}/status",
                  headers=admin_headers, json={"status": "preparing"})
        assert r.status_code == 200
        assert r.json()["status"] == "preparing"


# ---------- Admin menu CRUD ----------
class TestAdminMenu:
    def test_customer_cannot_create_menu(self, s, customer_headers):
        r = s.post(f"{API}/menu", headers=customer_headers,
                   json={"name": "TEST_Item", "category": "coffee", "price": 99})
        assert r.status_code == 403

    def test_admin_menu_crud(self, s, admin_headers):
        # CREATE
        r = s.post(f"{API}/menu", headers=admin_headers,
                   json={"name": "TEST_AdminItem", "category": "coffee", "price": 199, "is_veg": True})
        assert r.status_code == 200, r.text
        item = r.json()
        item_id = item["id"]
        assert item["name"] == "TEST_AdminItem"

        # GET (verify persisted via list)
        r2 = s.get(f"{API}/menu")
        assert any(x["id"] == item_id for x in r2.json())

        # UPDATE
        r3 = s.put(f"{API}/menu/{item_id}", headers=admin_headers,
                   json={"price": 250})
        assert r3.status_code == 200
        assert r3.json()["price"] == 250

        # DELETE
        r4 = s.delete(f"{API}/menu/{item_id}", headers=admin_headers)
        assert r4.status_code == 200

        # Verify deletion
        r5 = s.get(f"{API}/menu")
        assert not any(x["id"] == item_id for x in r5.json())


# ---------- Admin stats ----------
class TestAdminStats:
    def test_stats_forbidden_for_customer(self, s, customer_headers):
        r = s.get(f"{API}/admin/stats", headers=customer_headers)
        assert r.status_code == 403

    def test_stats_admin(self, s, admin_headers):
        r = s.get(f"{API}/admin/stats", headers=admin_headers)
        assert r.status_code == 200
        data = r.json()
        for k in ("total_orders", "pending", "preparing", "ready", "completed",
                  "menu_count", "today_revenue", "total_revenue"):
            assert k in data
        assert data["menu_count"] == 145
