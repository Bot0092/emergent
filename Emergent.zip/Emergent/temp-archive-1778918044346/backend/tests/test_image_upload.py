"""Backend tests for the new menu-item image upload feature.

Covers:
- POST /api/menu accepts valid data:image/ base64 URL
- PUT /api/menu/{id} persists a base64 image (admin auth required)
- PUT /api/menu/{id} with image="" clears the image (sets to null)
- PUT /api/menu/{id} rejects non-data-URL strings with 400
- PUT /api/menu/{id} rejects images > 3MB with 400
- GET /api/menu returns the image field on items that have one
- Image endpoints require admin auth (401 unauth, 403 customer)
"""
import os
import pytest
import requests

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL", "https://order-brew-login.preview.emergentagent.com").rstrip("/")
API = f"{BASE_URL}/api"

ADMIN_TOKEN = "TEST_ADMIN_TOKEN_001"
CUSTOMER_TOKEN = "TEST_CUSTOMER_TOKEN_001"

# 1x1 red PNG, base64 — small valid data URL
TINY_PNG_DATA_URL = (
    "data:image/png;base64,"
    "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR4nGP8z8DwHwAFBQIAX8jx0gAAAABJRU5ErkJggg=="
)


@pytest.fixture(scope="module")
def s():
    sess = requests.Session()
    sess.headers.update({"Content-Type": "application/json"})
    return sess


@pytest.fixture(scope="module")
def admin_h():
    return {"Authorization": f"Bearer {ADMIN_TOKEN}"}


@pytest.fixture(scope="module")
def customer_h():
    return {"Authorization": f"Bearer {CUSTOMER_TOKEN}"}


@pytest.fixture
def created_item(s, admin_h):
    """Create a fresh TEST_ menu item and clean it up after the test."""
    r = s.post(
        f"{API}/menu",
        headers=admin_h,
        json={"name": "TEST_ImgItem", "category": "coffee", "price": 150, "is_veg": True},
    )
    assert r.status_code == 200, r.text
    item_id = r.json()["id"]
    yield item_id
    # cleanup
    s.delete(f"{API}/menu/{item_id}", headers=admin_h)


# ---------- Auth gating ----------
class TestImageAuth:
    def test_unauth_post_menu_returns_401(self, s):
        r = s.post(
            f"{API}/menu",
            json={"name": "TEST_NoAuth", "category": "coffee", "price": 99, "image": TINY_PNG_DATA_URL},
        )
        assert r.status_code == 401

    def test_customer_post_menu_returns_403(self, s, customer_h):
        r = s.post(
            f"{API}/menu",
            headers=customer_h,
            json={"name": "TEST_CustAuth", "category": "coffee", "price": 99, "image": TINY_PNG_DATA_URL},
        )
        assert r.status_code == 403

    def test_unauth_put_menu_returns_401(self, s, created_item):
        r = s.put(f"{API}/menu/{created_item}", json={"image": TINY_PNG_DATA_URL})
        assert r.status_code == 401

    def test_customer_put_menu_returns_403(self, s, customer_h, created_item):
        r = s.put(f"{API}/menu/{created_item}", headers=customer_h, json={"image": TINY_PNG_DATA_URL})
        assert r.status_code == 403


# ---------- POST /menu image acceptance ----------
class TestCreateWithImage:
    def test_create_with_valid_image_persists(self, s, admin_h):
        r = s.post(
            f"{API}/menu",
            headers=admin_h,
            json={
                "name": "TEST_NewImgItem",
                "category": "coffee",
                "price": 220,
                "is_veg": True,
                "image": TINY_PNG_DATA_URL,
            },
        )
        assert r.status_code == 200, r.text
        item = r.json()
        item_id = item["id"]
        assert item["image"] == TINY_PNG_DATA_URL
        try:
            # verify via GET /menu list contains image
            r2 = s.get(f"{API}/menu")
            assert r2.status_code == 200
            found = next((x for x in r2.json() if x["id"] == item_id), None)
            assert found is not None
            assert found.get("image") == TINY_PNG_DATA_URL
        finally:
            s.delete(f"{API}/menu/{item_id}", headers=admin_h)

    def test_create_rejects_non_data_url_image(self, s, admin_h):
        r = s.post(
            f"{API}/menu",
            headers=admin_h,
            json={
                "name": "TEST_BadImgItem",
                "category": "coffee",
                "price": 99,
                "image": "https://example.com/pic.png",  # not a data URL
            },
        )
        assert r.status_code == 400, r.text


# ---------- PUT /menu/{id} image flows ----------
class TestUpdateImage:
    def test_put_sets_image(self, s, admin_h, created_item):
        r = s.put(
            f"{API}/menu/{created_item}",
            headers=admin_h,
            json={"image": TINY_PNG_DATA_URL},
        )
        assert r.status_code == 200, r.text
        assert r.json()["image"] == TINY_PNG_DATA_URL

        # GET verifies persistence
        r2 = s.get(f"{API}/menu")
        found = next((x for x in r2.json() if x["id"] == created_item), None)
        assert found is not None
        assert found.get("image") == TINY_PNG_DATA_URL

    def test_put_empty_string_clears_image(self, s, admin_h, created_item):
        # set first
        r = s.put(f"{API}/menu/{created_item}", headers=admin_h, json={"image": TINY_PNG_DATA_URL})
        assert r.status_code == 200
        assert r.json()["image"] == TINY_PNG_DATA_URL

        # then clear with empty string
        r2 = s.put(f"{API}/menu/{created_item}", headers=admin_h, json={"image": ""})
        assert r2.status_code == 200, r2.text
        assert r2.json().get("image") is None

        # GET verifies persistence
        r3 = s.get(f"{API}/menu")
        found = next((x for x in r3.json() if x["id"] == created_item), None)
        assert found is not None
        assert found.get("image") in (None, "")  # null/None after clear

    def test_put_rejects_non_data_url(self, s, admin_h, created_item):
        r = s.put(
            f"{API}/menu/{created_item}",
            headers=admin_h,
            json={"image": "not-a-data-url"},
        )
        assert r.status_code == 400, r.text
        detail = r.json().get("detail", "")
        assert "data:image" in detail or "data" in detail.lower()

    def test_put_rejects_http_url(self, s, admin_h, created_item):
        r = s.put(
            f"{API}/menu/{created_item}",
            headers=admin_h,
            json={"image": "https://cdn.example.com/x.jpg"},
        )
        assert r.status_code == 400

    def test_put_rejects_oversized_image(self, s, admin_h, created_item):
        # Build a string longer than MAX_IMAGE_BYTES (3MB) that still starts with data:image/
        # MAX_IMAGE_BYTES = 3 * 1024 * 1024 = 3145728
        oversized = "data:image/png;base64," + ("A" * (3 * 1024 * 1024 + 100))
        r = s.put(
            f"{API}/menu/{created_item}",
            headers=admin_h,
            json={"image": oversized},
        )
        assert r.status_code == 400, f"expected 400 for oversized, got {r.status_code}"
        detail = r.json().get("detail", "").lower()
        assert "too large" in detail or "large" in detail

    def test_put_404_for_missing_item(self, s, admin_h):
        r = s.put(
            f"{API}/menu/does-not-exist-xyz",
            headers=admin_h,
            json={"image": TINY_PNG_DATA_URL},
        )
        assert r.status_code == 404


# ---------- GET /menu returns image ----------
class TestMenuListImage:
    def test_menu_list_includes_image_field(self, s, admin_h, created_item):
        # set image first
        r = s.put(f"{API}/menu/{created_item}", headers=admin_h, json={"image": TINY_PNG_DATA_URL})
        assert r.status_code == 200
        r2 = s.get(f"{API}/menu")
        assert r2.status_code == 200
        items = r2.json()
        found = next((x for x in items if x["id"] == created_item), None)
        assert found is not None
        assert "image" in found
        assert found["image"] == TINY_PNG_DATA_URL
