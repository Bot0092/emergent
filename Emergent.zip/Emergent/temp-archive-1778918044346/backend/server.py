from fastapi import FastAPI, APIRouter, HTTPException, Request, Response, Header, Depends
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import logging
import uuid
import httpx
from pathlib import Path
from pydantic import BaseModel, Field, ConfigDict, field_validator
from typing import List, Optional, Literal
from datetime import datetime, timezone, timedelta

from seed_data import CATEGORIES, MENU_ITEMS

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

ADMIN_EMAIL = "freefund804@gmail.com"
# Primary admins are configurable via env var (comma-separated).
# Both can sign in as admin AND can add/remove additional admins.
_default_primary_admins = "freefund804@gmail.com,harshsharma12m@gmail.com"
PRIMARY_ADMIN_EMAILS = [
    e.strip().lower()
    for e in (os.environ.get("PRIMARY_ADMIN_EMAILS") or _default_primary_admins).split(",")
    if e.strip()
]
SESSION_DAYS = 7

app = FastAPI(title="The Crunchy Bite API")
api_router = APIRouter(prefix="/api")

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


# ---------- Models ----------
class Variant(BaseModel):
    label: str
    price: float


class MenuItem(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    name: str
    category: str
    price: float
    is_veg: bool = True
    variants: List[Variant] = []
    description: Optional[str] = None
    available: bool = True
    image: Optional[str] = None
    rating_avg: float = 0.0
    rating_count: int = 0


class MenuItemCreate(BaseModel):
    name: str
    category: str
    price: float
    is_veg: bool = True
    variants: List[Variant] = []
    description: Optional[str] = None
    available: bool = True
    image: Optional[str] = None


class MenuItemUpdate(BaseModel):
    name: Optional[str] = None
    category: Optional[str] = None
    price: Optional[float] = None
    is_veg: Optional[bool] = None
    variants: Optional[List[Variant]] = None
    description: Optional[str] = None
    available: Optional[bool] = None
    image: Optional[str] = None


class Category(BaseModel):
    slug: str
    name: str
    order: int = 0
    icon: Optional[str] = None


class User(BaseModel):
    user_id: str
    email: str
    name: str
    picture: Optional[str] = None
    role: Literal["customer", "admin"] = "customer"


class CartLine(BaseModel):
    item_id: str
    name: str
    variant_label: Optional[str] = None
    price: float
    quantity: int


class OrderCreate(BaseModel):
    items: List[CartLine]
    order_type: Literal["dine-in", "takeaway", "delivery"]
    table_number: Optional[str] = None
    delivery_address: Optional[str] = None
    delivery_phone: Optional[str] = None
    notes: Optional[str] = None
    coupon_code: Optional[str] = None


class Order(BaseModel):
    id: str
    user_id: str
    user_name: str
    user_email: str
    items: List[CartLine]
    order_type: str
    table_number: Optional[str] = None
    delivery_address: Optional[str] = None
    delivery_phone: Optional[str] = None
    notes: Optional[str] = None
    subtotal: Optional[float] = None
    delivery_fee: float = 0.0
    discount: float = 0.0
    coupon_code: Optional[str] = None
    total: float
    status: Literal["pending", "preparing", "ready", "completed", "cancelled"] = "pending"
    cancel_reason: Optional[str] = None
    payment_status: Literal["unpaid", "paid"] = "unpaid"
    eta_minutes: Optional[int] = None
    eta_at: Optional[str] = None
    rating: Optional[int] = None
    rating_comment: Optional[str] = None
    rated_at: Optional[str] = None
    created_at: datetime
    updated_at: datetime

    @field_validator("table_number", mode="before")
    @classmethod
    def _coerce_table_number(cls, v):
        return None if v is None else str(v)


class OrderStatusUpdate(BaseModel):
    status: Literal["pending", "preparing", "ready", "completed", "cancelled"]


class OrderEtaUpdate(BaseModel):
    eta_minutes: int


class OrderCancel(BaseModel):
    reason: Optional[str] = None


class RatingCreate(BaseModel):
    rating: int
    comment: Optional[str] = None


class AdminEmailCreate(BaseModel):
    email: str


class AdminEmailItem(BaseModel):
    email: str
    added_at: str
    added_by: str


class CouponCreate(BaseModel):
    code: str
    discount_type: Literal["flat", "percent"]
    value: float
    min_order: float = 0.0
    max_discount: Optional[float] = None  # cap for percent coupons
    active: bool = True
    applies_to_categories: List[str] = []
    applies_to_items: List[str] = []


class CartLineLite(BaseModel):
    item_id: Optional[str] = None
    price: float
    quantity: int


class CouponValidateRequest(BaseModel):
    code: str
    subtotal: float
    items: Optional[List[CartLineLite]] = None


CANCEL_WINDOW_SECONDS = 5 * 60


class Settings(BaseModel):
    delivery_fee_enabled: bool = False
    delivery_fee: float = 0.0
    free_delivery_above: float = 0.0  # 0 = disabled; otherwise subtotal >= this -> fee waived
    cafe_open: bool = True
    closed_message: str = "We're closed right now. Please check back soon!"
    hero_image: Optional[str] = None


ETA_DEFAULTS = {"dine-in": 10, "takeaway": 15, "delivery": 30}


async def get_settings_doc() -> dict:
    doc = await db.settings.find_one({"key": "global"}, {"_id": 0})
    if not doc:
        doc = {"key": "global", "delivery_fee_enabled": False, "delivery_fee": 0.0, "cafe_open": True, "closed_message": "We're closed right now. Please check back soon!"}
        await db.settings.insert_one(dict(doc))
    return doc


async def is_admin_email(email: str) -> bool:
    if not email:
        return False
    e = email.lower()
    if e in PRIMARY_ADMIN_EMAILS:
        return True
    doc = await db.admin_emails.find_one({"email": e})
    return doc is not None


def _is_primary_admin(user: "User") -> bool:
    return user.email.lower() in PRIMARY_ADMIN_EMAILS


# ---------- Auth helpers ----------
async def get_session_token(request: Request, authorization: Optional[str] = Header(None)) -> Optional[str]:
    token = request.cookies.get("session_token")
    if not token and authorization and authorization.lower().startswith("bearer "):
        token = authorization.split(" ", 1)[1].strip()
    return token


async def get_current_user(request: Request, authorization: Optional[str] = Header(None)) -> User:
    token = await get_session_token(request, authorization)
    if not token:
        raise HTTPException(status_code=401, detail="Not authenticated")

    session_doc = await db.user_sessions.find_one({"session_token": token}, {"_id": 0})
    if not session_doc:
        raise HTTPException(status_code=401, detail="Invalid session")

    expires_at = session_doc["expires_at"]
    if isinstance(expires_at, str):
        expires_at = datetime.fromisoformat(expires_at)
    if expires_at.tzinfo is None:
        expires_at = expires_at.replace(tzinfo=timezone.utc)
    if expires_at < datetime.now(timezone.utc):
        raise HTTPException(status_code=401, detail="Session expired")

    user_doc = await db.users.find_one({"user_id": session_doc["user_id"]}, {"_id": 0})
    if not user_doc:
        raise HTTPException(status_code=401, detail="User not found")
    return User(**user_doc)


async def require_admin(user: User = Depends(get_current_user)) -> User:
    if user.role != "admin":
        raise HTTPException(status_code=403, detail="Admin access required")
    return user


# ---------- Auth routes ----------
@api_router.post("/auth/session")
async def auth_session(request: Request, response: Response):
    """Exchange Emergent session_id for our session_token + user info."""
    body = await request.json()
    session_id = body.get("session_id")
    if not session_id:
        raise HTTPException(status_code=400, detail="session_id required")

    async with httpx.AsyncClient(timeout=15.0) as hc:
        r = await hc.get(
            "https://demobackend.emergentagent.com/auth/v1/env/oauth/session-data",
            headers={"X-Session-ID": session_id},
        )
    if r.status_code != 200:
        raise HTTPException(status_code=401, detail="Invalid emergent session")
    data = r.json()
    email = data["email"]
    name = data.get("name", email.split("@")[0])
    picture = data.get("picture")
    session_token = data["session_token"]

    role = "admin" if await is_admin_email(email) else "customer"

    existing = await db.users.find_one({"email": email}, {"_id": 0})
    if existing:
        user_id = existing["user_id"]
        await db.users.update_one(
            {"user_id": user_id},
            {"$set": {"name": name, "picture": picture, "role": role}},
        )
    else:
        user_id = f"user_{uuid.uuid4().hex[:12]}"
        await db.users.insert_one({
            "user_id": user_id,
            "email": email,
            "name": name,
            "picture": picture,
            "role": role,
            "created_at": datetime.now(timezone.utc).isoformat(),
        })

    expires_at = datetime.now(timezone.utc) + timedelta(days=SESSION_DAYS)
    await db.user_sessions.update_one(
        {"session_token": session_token},
        {"$set": {
            "session_token": session_token,
            "user_id": user_id,
            "expires_at": expires_at,
            "created_at": datetime.now(timezone.utc),
        }},
        upsert=True,
    )

    response.set_cookie(
        key="session_token",
        value=session_token,
        max_age=SESSION_DAYS * 24 * 60 * 60,
        httponly=True,
        secure=True,
        samesite="none",
        path="/",
    )
    return {
        "user": {"user_id": user_id, "email": email, "name": name, "picture": picture, "role": role},
        "session_token": session_token,
    }


@api_router.get("/auth/me", response_model=User)
async def auth_me(user: User = Depends(get_current_user)):
    return user


@api_router.post("/auth/logout")
async def auth_logout(request: Request, response: Response, authorization: Optional[str] = Header(None)):
    token = await get_session_token(request, authorization)
    if token:
        await db.user_sessions.delete_one({"session_token": token})
    response.delete_cookie("session_token", path="/", samesite="none", secure=True)
    return {"ok": True}


# ---------- Menu routes ----------
@api_router.get("/categories", response_model=List[Category])
async def list_categories():
    cats = await db.categories.find({}, {"_id": 0}).sort("order", 1).to_list(1000)
    return cats


@api_router.get("/public-stats")
async def public_stats():
    """Lightweight public counters for the hero strip. Excludes cancelled orders."""
    total_users = await db.users.count_documents({})
    start_of_day = datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0).isoformat()
    today_orders = await db.orders.count_documents({
        "created_at": {"$gte": start_of_day},
        "status": {"$ne": "cancelled"},
    })
    total_orders = await db.orders.count_documents({"status": {"$ne": "cancelled"}})
    return {
        "total_users": total_users,
        "today_orders": today_orders,
        "total_orders": total_orders,
    }


# ---------- Settings ----------
@api_router.get("/settings", response_model=Settings)
async def get_public_settings():
    doc = await get_settings_doc()
    return Settings(
        delivery_fee_enabled=bool(doc.get("delivery_fee_enabled", False)),
        delivery_fee=float(doc.get("delivery_fee", 0.0)),
        free_delivery_above=float(doc.get("free_delivery_above", 0.0)),
        cafe_open=bool(doc.get("cafe_open", True)),
        closed_message=str(doc.get("closed_message") or "We're closed right now. Please check back soon!"),
        hero_image=doc.get("hero_image") or None,
    )


@api_router.put("/settings", response_model=Settings)
async def update_settings(payload: Settings, _: User = Depends(require_admin)):
    if payload.delivery_fee < 0 or payload.delivery_fee > 10000:
        raise HTTPException(status_code=400, detail="delivery_fee must be between 0 and 10000")
    if payload.free_delivery_above < 0 or payload.free_delivery_above > 100000:
        raise HTTPException(status_code=400, detail="free_delivery_above must be between 0 and 100000")
    closed_msg = (payload.closed_message or "").strip() or "We're closed right now. Please check back soon!"
    # Validate / normalise hero image (allow base64 data url OR https URL OR empty to clear)
    hero = payload.hero_image
    if hero is None or hero == "":
        hero_to_store = None
    elif hero.startswith("data:image/"):
        if len(hero) > 4 * 1024 * 1024:
            raise HTTPException(status_code=400, detail="Hero image too large (max ~3MB).")
        hero_to_store = hero
    elif hero.startswith("http://") or hero.startswith("https://"):
        hero_to_store = hero
    else:
        raise HTTPException(status_code=400, detail="hero_image must be a data:image/* URL or https:// URL")

    await db.settings.update_one(
        {"key": "global"},
        {"$set": {
            "key": "global",
            "delivery_fee_enabled": bool(payload.delivery_fee_enabled),
            "delivery_fee": float(payload.delivery_fee),
            "free_delivery_above": float(payload.free_delivery_above),
            "cafe_open": bool(payload.cafe_open),
            "closed_message": closed_msg,
            "hero_image": hero_to_store,
        }},
        upsert=True,
    )
    return Settings(
        delivery_fee_enabled=bool(payload.delivery_fee_enabled),
        delivery_fee=float(payload.delivery_fee),
        free_delivery_above=float(payload.free_delivery_above),
        cafe_open=bool(payload.cafe_open),
        closed_message=closed_msg,
        hero_image=hero_to_store,
    )


async def _item_ratings_map() -> dict:
    pipeline = [
        {"$match": {"rating": {"$ne": None}}},
        {"$unwind": "$items"},
        {"$group": {
            "_id": "$items.item_id",
            "avg": {"$avg": "$rating"},
            "count": {"$sum": 1},
        }},
    ]
    docs = await db.orders.aggregate(pipeline).to_list(5000)
    return {d["_id"]: {"avg": round(float(d["avg"] or 0), 1), "count": int(d["count"])} for d in docs}


@api_router.get("/menu", response_model=List[MenuItem])
async def list_menu():
    items = await db.menu_items.find({}, {"_id": 0}).to_list(2000)
    return items


def _first_name(name: Optional[str]) -> str:
    if not name:
        return "Guest"
    parts = name.strip().split()
    if not parts:
        return "Guest"
    first = parts[0]
    last_initial = (parts[-1][0].upper() + ".") if len(parts) > 1 else ""
    return f"{first} {last_initial}".strip()


@api_router.get("/reviews")
async def public_reviews(limit: int = 20):
    limit = max(1, min(int(limit or 20), 100))
    docs = await db.orders.find(
        {"rating": {"$ne": None}},
        {"_id": 0, "id": 1, "user_name": 1, "rating": 1, "rating_comment": 1, "rated_at": 1, "items": 1},
    ).sort("rated_at", -1).to_list(limit)
    out = []
    for d in docs:
        items_preview = [
            f"{i.get('name')}{' (' + i['variant_label'] + ')' if i.get('variant_label') else ''}"
            for i in (d.get("items") or [])[:3]
        ]
        out.append({
            "order_id": d.get("id"),
            "user_name": _first_name(d.get("user_name")),
            "rating": d.get("rating"),
            "comment": d.get("rating_comment"),
            "rated_at": d.get("rated_at"),
            "items": items_preview,
        })
    avg = round(sum(r["rating"] for r in out) / len(out), 1) if out else 0
    return {"count": len(out), "average": avg, "items": out}


@api_router.get("/items/{item_id}/reviews")
async def item_reviews(item_id: str, limit: int = 10):
    limit = max(1, min(int(limit or 10), 50))
    pipeline = [
        {"$match": {"rating": {"$ne": None}, "items.item_id": item_id}},
        {"$sort": {"rated_at": -1}},
        {"$limit": limit},
        {"$project": {"_id": 0, "id": 1, "user_name": 1, "rating": 1, "rating_comment": 1, "rated_at": 1}},
    ]
    docs = await db.orders.aggregate(pipeline).to_list(limit)
    return [{
        "order_id": d.get("id"),
        "user_name": _first_name(d.get("user_name")),
        "rating": d.get("rating"),
        "comment": d.get("rating_comment"),
        "rated_at": d.get("rated_at"),
    } for d in docs]


@api_router.post("/menu", response_model=MenuItem)
async def create_menu_item(payload: MenuItemCreate, _: User = Depends(require_admin)):
    if payload.image:
        _validate_image_payload(payload.image)
    item = MenuItem(**payload.model_dump())
    doc = item.model_dump()
    await db.menu_items.insert_one(doc)
    return item


MAX_IMAGE_BYTES = 3 * 1024 * 1024  # ~3MB base64 string


def _validate_image_payload(image: Optional[str]):
    if not image:
        return
    if not image.startswith("data:image/"):
        raise HTTPException(status_code=400, detail="Image must be a data:image/* URL")
    if len(image) > MAX_IMAGE_BYTES:
        raise HTTPException(status_code=400, detail="Image too large. Please use a smaller photo (max ~3MB).")


@api_router.put("/menu/{item_id}", response_model=MenuItem)
async def update_menu_item(item_id: str, payload: MenuItemUpdate, _: User = Depends(require_admin)):
    update = {k: v for k, v in payload.model_dump().items() if v is not None}
    if not update:
        raise HTTPException(status_code=400, detail="Nothing to update")
    if "image" in update:
        if update["image"] == "":
            update["image"] = None  # explicit clear
        else:
            _validate_image_payload(update["image"])
    res = await db.menu_items.update_one({"id": item_id}, {"$set": update})
    if res.matched_count == 0:
        raise HTTPException(status_code=404, detail="Item not found")
    doc = await db.menu_items.find_one({"id": item_id}, {"_id": 0})
    return doc


@api_router.delete("/menu/{item_id}")
async def delete_menu_item(item_id: str, _: User = Depends(require_admin)):
    res = await db.menu_items.delete_one({"id": item_id})
    if res.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Item not found")
    return {"ok": True}


# ---------- Orders ----------
def _serialize_order(doc) -> dict:
    for k in ("created_at", "updated_at"):
        v = doc.get(k)
        if isinstance(v, datetime):
            doc[k] = v.isoformat()
    return doc


async def _resolve_coupon(code: Optional[str], subtotal: float, items: Optional[List] = None) -> dict:
    """Return {'discount': float, 'coupon_code': normalized_code} or zeros if not applicable.

    Item/category restrictions: discount only applies to the value of matching items.
    `items` may be cart lines (CartLine or CartLineLite) — needs `item_id`, `price`, `quantity`.
    Raises HTTPException on invalid/inactive/min-order-not-met / no eligible items.
    """
    if not code:
        return {"discount": 0.0, "coupon_code": None}
    norm = code.strip().upper()
    if not norm:
        return {"discount": 0.0, "coupon_code": None}
    doc = await db.coupons.find_one({"code": norm}, {"_id": 0})
    if not doc:
        raise HTTPException(status_code=400, detail="Invalid coupon code")
    if not doc.get("active", True):
        raise HTTPException(status_code=400, detail="This coupon is no longer active")
    min_order = float(doc.get("min_order") or 0.0)
    if subtotal < min_order:
        raise HTTPException(status_code=400, detail=f"Add ₹{int(min_order - subtotal)} more to use this coupon (min order ₹{int(min_order)})")

    cat_filter = list(doc.get("applies_to_categories") or [])
    item_filter = list(doc.get("applies_to_items") or [])
    is_restricted = bool(cat_filter or item_filter)

    # Compute the eligible subtotal
    if is_restricted:
        if not items:
            raise HTTPException(status_code=400, detail="Cart info required to apply this coupon")
        # Resolve item_id -> category from menu_items
        item_ids = [getattr(it, "item_id", None) or it.get("item_id") for it in items]
        item_ids = [i for i in item_ids if i]
        menu_docs = await db.menu_items.find({"id": {"$in": item_ids}}, {"_id": 0, "id": 1, "category": 1, "name": 1}).to_list(1000) if item_ids else []
        id_to_cat = {m["id"]: m.get("category") for m in menu_docs}
        eligible_subtotal = 0.0
        eligible_names = []
        for it in items:
            iid = getattr(it, "item_id", None) or it.get("item_id")
            price = float(getattr(it, "price", None) if hasattr(it, "price") else it.get("price") or 0)
            qty = int(getattr(it, "quantity", None) if hasattr(it, "quantity") else it.get("quantity") or 0)
            cat = id_to_cat.get(iid)
            if item_filter and iid in item_filter:
                eligible_subtotal += price * qty
                eligible_names.append(iid)
            elif cat_filter and cat in cat_filter:
                eligible_subtotal += price * qty
                eligible_names.append(iid)
        if eligible_subtotal <= 0:
            raise HTTPException(status_code=400, detail="This coupon doesn't apply to items in your cart")
    else:
        eligible_subtotal = subtotal

    if doc.get("discount_type") == "flat":
        discount = float(doc.get("value") or 0.0)
    else:  # percent
        pct = float(doc.get("value") or 0.0)
        discount = eligible_subtotal * pct / 100.0
        cap = doc.get("max_discount")
        if cap is not None:
            discount = min(discount, float(cap))
    discount = max(0.0, min(discount, eligible_subtotal))  # never exceed eligible items
    return {"discount": round(discount, 2), "coupon_code": norm}


@api_router.post("/orders", response_model=Order)
async def create_order(payload: OrderCreate, user: User = Depends(get_current_user)):
    if not payload.items:
        raise HTTPException(status_code=400, detail="Cart is empty")
    settings_doc = await get_settings_doc()
    if not settings_doc.get("cafe_open", True):
        raise HTTPException(status_code=403, detail=settings_doc.get("closed_message") or "Cafe is currently closed")
    if payload.order_type == "dine-in" and not payload.table_number:
        raise HTTPException(status_code=400, detail="Table number required for dine-in")
    if payload.order_type == "delivery":
        if not payload.delivery_address or not payload.delivery_phone:
            raise HTTPException(status_code=400, detail="Delivery address and phone required for delivery")
        # Validate Indian 10-digit mobile (starts with 6-9)
        digits = "".join(ch for ch in payload.delivery_phone if ch.isdigit())
        if len(digits) != 10 or digits[0] not in "6789":
            raise HTTPException(status_code=400, detail="Enter a valid 10-digit Indian mobile number")

    subtotal = sum(line.price * line.quantity for line in payload.items)
    delivery_fee = 0.0
    if payload.order_type == "delivery":
        if settings_doc.get("delivery_fee_enabled"):
            delivery_fee = float(settings_doc.get("delivery_fee") or 0.0)
            free_above = float(settings_doc.get("free_delivery_above") or 0.0)
            if free_above > 0 and subtotal >= free_above:
                delivery_fee = 0.0
    coupon_info = await _resolve_coupon(payload.coupon_code, subtotal, payload.items)
    discount = coupon_info["discount"]
    total = max(0.0, subtotal + delivery_fee - discount)

    now = datetime.now(timezone.utc)
    order_id = f"ord_{uuid.uuid4().hex[:10]}"
    order_doc = {
        "id": order_id,
        "user_id": user.user_id,
        "user_name": user.name,
        "user_email": user.email,
        "items": [line.model_dump() for line in payload.items],
        "order_type": payload.order_type,
        "table_number": payload.table_number,
        "delivery_address": payload.delivery_address,
        "delivery_phone": payload.delivery_phone,
        "notes": payload.notes,
        "subtotal": subtotal,
        "delivery_fee": delivery_fee,
        "discount": discount,
        "coupon_code": coupon_info["coupon_code"],
        "total": total,
        "status": "pending",
        "payment_status": "unpaid",
        "eta_minutes": ETA_DEFAULTS.get(payload.order_type, 15),
        "eta_at": None,
        "created_at": now.isoformat(),
        "updated_at": now.isoformat(),
    }
    await db.orders.insert_one(dict(order_doc))
    # Track usage
    if coupon_info["coupon_code"]:
        await db.coupons.update_one(
            {"code": coupon_info["coupon_code"]},
            {"$inc": {"used_count": 1}},
        )
    return _serialize_order(order_doc)


@api_router.get("/orders/me", response_model=List[Order])
async def list_my_orders(user: User = Depends(get_current_user)):
    docs = await db.orders.find({"user_id": user.user_id}, {"_id": 0}).sort("created_at", -1).to_list(500)
    return [_serialize_order(d) for d in docs]


@api_router.get("/orders", response_model=List[Order])
async def list_all_orders(_: User = Depends(require_admin)):
    docs = await db.orders.find({}, {"_id": 0}).sort("created_at", -1).to_list(1000)
    return [_serialize_order(d) for d in docs]


@api_router.put("/orders/{order_id}/status", response_model=Order)
async def update_order_status(order_id: str, payload: OrderStatusUpdate, _: User = Depends(require_admin)):
    order = await db.orders.find_one({"id": order_id}, {"_id": 0})
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")
    now = datetime.now(timezone.utc)
    update = {"status": payload.status, "updated_at": now.isoformat()}
    # Set eta_at when transitioning to "preparing"
    if payload.status == "preparing":
        eta_minutes = order.get("eta_minutes") or ETA_DEFAULTS.get(order.get("order_type", ""), 15)
        eta_at = (now + timedelta(minutes=eta_minutes)).isoformat()
        update["eta_minutes"] = eta_minutes
        update["eta_at"] = eta_at
    await db.orders.update_one({"id": order_id}, {"$set": update})
    doc = await db.orders.find_one({"id": order_id}, {"_id": 0})
    return _serialize_order(doc)


@api_router.put("/orders/{order_id}/eta", response_model=Order)
async def update_order_eta(order_id: str, payload: OrderEtaUpdate, _: User = Depends(require_admin)):
    if payload.eta_minutes < 0 or payload.eta_minutes > 240:
        raise HTTPException(status_code=400, detail="eta_minutes must be between 0 and 240")
    order = await db.orders.find_one({"id": order_id}, {"_id": 0})
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")
    now = datetime.now(timezone.utc)
    update = {"eta_minutes": payload.eta_minutes, "updated_at": now.isoformat()}
    if order.get("status") == "preparing":
        update["eta_at"] = (now + timedelta(minutes=payload.eta_minutes)).isoformat()
    await db.orders.update_one({"id": order_id}, {"$set": update})
    doc = await db.orders.find_one({"id": order_id}, {"_id": 0})
    return _serialize_order(doc)


@api_router.put("/orders/{order_id}/cancel", response_model=Order)
async def cancel_order(order_id: str, payload: OrderCancel, user: User = Depends(get_current_user)):
    order = await db.orders.find_one({"id": order_id}, {"_id": 0})
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")
    if order["user_id"] != user.user_id and user.role != "admin":
        raise HTTPException(status_code=403, detail="Not your order")
    if order["status"] != "pending":
        raise HTTPException(status_code=400, detail="Order can no longer be cancelled — it's already being prepared")
    # 5-minute window for customers; admins can cancel any pending order anytime
    if user.role != "admin":
        try:
            created_at = datetime.fromisoformat(order["created_at"].replace("Z", "+00:00"))
        except Exception:
            created_at = datetime.now(timezone.utc)
        elapsed = (datetime.now(timezone.utc) - created_at).total_seconds()
        if elapsed > CANCEL_WINDOW_SECONDS:
            raise HTTPException(status_code=400, detail="Cancel window of 5 minutes has passed")
    now = datetime.now(timezone.utc).isoformat()
    await db.orders.update_one(
        {"id": order_id},
        {"$set": {"status": "cancelled", "cancel_reason": payload.reason or "Cancelled by customer", "updated_at": now}},
    )
    doc = await db.orders.find_one({"id": order_id}, {"_id": 0})
    return _serialize_order(doc)


@api_router.post("/orders/{order_id}/rating", response_model=Order)
async def rate_order(order_id: str, payload: RatingCreate, user: User = Depends(get_current_user)):
    if payload.rating < 1 or payload.rating > 5:
        raise HTTPException(status_code=400, detail="Rating must be 1-5")
    order = await db.orders.find_one({"id": order_id}, {"_id": 0})
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")
    if order["user_id"] != user.user_id:
        raise HTTPException(status_code=403, detail="Not your order")
    if order.get("status") != "completed":
        raise HTTPException(status_code=400, detail="You can rate only after the order is completed")
    if order.get("rating"):
        raise HTTPException(status_code=400, detail="You've already rated this order")
    now = datetime.now(timezone.utc).isoformat()
    await db.orders.update_one(
        {"id": order_id},
        {"$set": {
            "rating": int(payload.rating),
            "rating_comment": (payload.comment or "").strip()[:1000],
            "rated_at": now,
            "updated_at": now,
        }},
    )
    doc = await db.orders.find_one({"id": order_id}, {"_id": 0})
    return _serialize_order(doc)


@api_router.get("/ratings")
async def list_ratings(_: User = Depends(require_admin)):
    docs = await db.orders.find({"rating": {"$exists": True, "$ne": None}}, {"_id": 0}).sort("rated_at", -1).to_list(500)
    items = [{
        "order_id": d["id"],
        "user_name": d.get("user_name"),
        "user_email": d.get("user_email"),
        "rating": d.get("rating"),
        "comment": d.get("rating_comment"),
        "rated_at": d.get("rated_at"),
        "total": d.get("total"),
        "order_type": d.get("order_type"),
        "items": [{
            "name": i.get("name"),
            "variant_label": i.get("variant_label"),
            "quantity": i.get("quantity"),
        } for i in (d.get("items") or [])],
    } for d in docs]
    avg = round(sum(r["rating"] for r in items) / len(items), 2) if items else 0
    return {"count": len(items), "average": avg, "items": items}


# ---------- Coupons ----------
def _serialize_coupon(d: dict) -> dict:
    return {
        "code": d.get("code"),
        "discount_type": d.get("discount_type"),
        "value": float(d.get("value") or 0),
        "min_order": float(d.get("min_order") or 0),
        "max_discount": d.get("max_discount"),
        "active": bool(d.get("active", True)),
        "used_count": int(d.get("used_count") or 0),
        "created_at": d.get("created_at"),
        "applies_to_categories": list(d.get("applies_to_categories") or []),
        "applies_to_items": list(d.get("applies_to_items") or []),
    }


@api_router.get("/coupons")
async def list_coupons(_: User = Depends(require_admin)):
    docs = await db.coupons.find({}, {"_id": 0}).sort("created_at", -1).to_list(500)
    return [_serialize_coupon(d) for d in docs]


@api_router.post("/coupons")
async def create_coupon(payload: CouponCreate, _: User = Depends(require_admin)):
    code = (payload.code or "").strip().upper()
    if not code or not all(c.isalnum() or c in "-_" for c in code) or len(code) > 24:
        raise HTTPException(status_code=400, detail="Code must be 1-24 alphanumeric chars (- and _ allowed)")
    if payload.value <= 0:
        raise HTTPException(status_code=400, detail="Discount value must be positive")
    if payload.discount_type == "percent" and payload.value > 100:
        raise HTTPException(status_code=400, detail="Percent discount cannot exceed 100")
    if payload.min_order < 0 or payload.min_order > 100000:
        raise HTTPException(status_code=400, detail="Min order out of range")
    if payload.max_discount is not None and payload.max_discount < 0:
        raise HTTPException(status_code=400, detail="Max discount must be ≥ 0")
    existing = await db.coupons.find_one({"code": code})
    if existing:
        raise HTTPException(status_code=400, detail="Coupon code already exists")
    doc = {
        "code": code,
        "discount_type": payload.discount_type,
        "value": float(payload.value),
        "min_order": float(payload.min_order),
        "max_discount": float(payload.max_discount) if payload.max_discount is not None else None,
        "active": bool(payload.active),
        "used_count": 0,
        "applies_to_categories": [c.strip() for c in (payload.applies_to_categories or []) if c and c.strip()],
        "applies_to_items": [i.strip() for i in (payload.applies_to_items or []) if i and i.strip()],
        "created_at": datetime.now(timezone.utc).isoformat(),
    }
    await db.coupons.insert_one(dict(doc))
    return _serialize_coupon(doc)


@api_router.put("/coupons/{code}/toggle")
async def toggle_coupon(code: str, _: User = Depends(require_admin)):
    norm = code.strip().upper()
    doc = await db.coupons.find_one({"code": norm}, {"_id": 0})
    if not doc:
        raise HTTPException(status_code=404, detail="Coupon not found")
    new_state = not bool(doc.get("active", True))
    await db.coupons.update_one({"code": norm}, {"$set": {"active": new_state}})
    doc["active"] = new_state
    return _serialize_coupon(doc)


@api_router.delete("/coupons/{code}")
async def delete_coupon(code: str, _: User = Depends(require_admin)):
    norm = code.strip().upper()
    res = await db.coupons.delete_one({"code": norm})
    if res.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Coupon not found")
    return {"ok": True}


@api_router.post("/coupons/validate")
async def validate_coupon(payload: CouponValidateRequest, _: User = Depends(get_current_user)):
    info = await _resolve_coupon(payload.code, float(payload.subtotal or 0), payload.items)
    if not info["coupon_code"]:
        raise HTTPException(status_code=400, detail="Enter a coupon code")
    doc = await db.coupons.find_one({"code": info["coupon_code"]}, {"_id": 0})
    return {
        "code": info["coupon_code"],
        "discount": info["discount"],
        "discount_type": doc.get("discount_type"),
        "value": float(doc.get("value") or 0),
        "min_order": float(doc.get("min_order") or 0),
        "applies_to_categories": list(doc.get("applies_to_categories") or []),
        "applies_to_items": list(doc.get("applies_to_items") or []),
    }


@api_router.get("/coupons/{code}/usage")
async def coupon_usage(code: str, _: User = Depends(require_admin)):
    norm = code.strip().upper()
    coupon = await db.coupons.find_one({"code": norm}, {"_id": 0})
    if not coupon:
        raise HTTPException(status_code=404, detail="Coupon not found")
    orders = await db.orders.find(
        {"coupon_code": norm},
        {"_id": 0, "id": 1, "user_name": 1, "user_email": 1, "discount": 1, "total": 1, "order_type": 1, "status": 1, "created_at": 1},
    ).sort("created_at", -1).to_list(500)
    total_discount = sum(float(o.get("discount") or 0) for o in orders)
    return {
        "code": norm,
        "used_count": int(coupon.get("used_count") or 0),
        "total_discount_given": round(total_discount, 2),
        "orders": orders,
    }


# ---------- Admin emails management ----------
@api_router.get("/admins")
async def list_admin_emails(user: User = Depends(require_admin)):
    docs = await db.admin_emails.find({}, {"_id": 0}).sort("added_at", -1).to_list(500)
    return {
        "primary_admin": ADMIN_EMAIL,
        "primary_admins": PRIMARY_ADMIN_EMAILS,
        "is_primary": _is_primary_admin(user),
        "admins": docs,
    }


@api_router.post("/admins")
async def add_admin_email(payload: AdminEmailCreate, user: User = Depends(require_admin)):
    if not _is_primary_admin(user):
        raise HTTPException(status_code=403, detail="Only the primary admin can add admins")
    email = (payload.email or "").strip().lower()
    if "@" not in email or " " in email:
        raise HTTPException(status_code=400, detail="Enter a valid email")
    if email in PRIMARY_ADMIN_EMAILS:
        raise HTTPException(status_code=400, detail="This is already a primary admin")
    existing = await db.admin_emails.find_one({"email": email})
    if existing:
        raise HTTPException(status_code=400, detail="Email is already an admin")
    now = datetime.now(timezone.utc).isoformat()
    await db.admin_emails.insert_one({"email": email, "added_at": now, "added_by": user.email})
    # If a user already exists with this email, upgrade their role immediately
    await db.users.update_one({"email": email}, {"$set": {"role": "admin"}})
    return {"email": email, "added_at": now, "added_by": user.email}


@api_router.delete("/admins/{email}")
async def remove_admin_email(email: str, user: User = Depends(require_admin)):
    if not _is_primary_admin(user):
        raise HTTPException(status_code=403, detail="Only the primary admin can remove admins")
    email = email.strip().lower()
    if email in PRIMARY_ADMIN_EMAILS:
        raise HTTPException(status_code=400, detail="Cannot remove a primary admin")
    res = await db.admin_emails.delete_one({"email": email})
    if res.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Admin not found")
    # Downgrade existing user record
    await db.users.update_one({"email": email}, {"$set": {"role": "customer"}})
    return {"ok": True}


class RevenueResetRequest(BaseModel):
    scope: Literal["today", "total"]


class RevenueAdjustRequest(BaseModel):
    scope: Literal["today", "total"]
    amount: float  # positive to add, negative to subtract
    reason: Optional[str] = None


# ---------- Admin stats ----------
async def _get_revenue_resets() -> dict:
    doc = await db.settings.find_one({"key": "revenue_resets"}, {"_id": 0}) or {}
    return {
        "today_reset_at": doc.get("today_reset_at"),
        "total_reset_at": doc.get("total_reset_at"),
    }


async def _sum_adjustments(scope: str, since: Optional[str] = None) -> float:
    match = {"scope": scope}
    if since:
        match["created_at"] = {"$gte": since}
    pipeline = [
        {"$match": match},
        {"$group": {"_id": None, "total": {"$sum": "$amount"}}},
    ]
    res = await db.revenue_adjustments.aggregate(pipeline).to_list(1)
    return float(res[0]["total"]) if res else 0.0


@api_router.post("/admin/revenue/adjust")
async def adjust_revenue(payload: RevenueAdjustRequest, user: User = Depends(require_admin)):
    if not _is_primary_admin(user):
        raise HTTPException(status_code=403, detail="Only a primary admin can adjust revenue")
    if abs(payload.amount) > 10_000_000:
        raise HTTPException(status_code=400, detail="Amount out of range")
    now = datetime.now(timezone.utc).isoformat()
    await db.revenue_adjustments.insert_one({
        "id": f"adj_{uuid.uuid4().hex[:10]}",
        "scope": payload.scope,
        "amount": float(payload.amount),
        "reason": (payload.reason or "").strip()[:200] or None,
        "by": user.email,
        "created_at": now,
    })
    return {"ok": True, "scope": payload.scope, "amount": payload.amount, "created_at": now}


@api_router.post("/admin/revenue/reset")
async def reset_revenue(payload: RevenueResetRequest, user: User = Depends(require_admin)):
    if not _is_primary_admin(user):
        raise HTTPException(status_code=403, detail="Only a primary admin can reset revenue")
    now = datetime.now(timezone.utc).isoformat()
    field = "today_reset_at" if payload.scope == "today" else "total_reset_at"
    await db.settings.update_one(
        {"key": "revenue_resets"},
        {"$set": {"key": "revenue_resets", field: now}},
        upsert=True,
    )
    # Also clear adjustments that would otherwise remain in the new period
    if payload.scope == "today":
        # Drop today-scope adjustments older than now (i.e. earlier today)
        await db.revenue_adjustments.delete_many({"scope": "today", "created_at": {"$lt": now}})
    else:
        # Total reset: drop all total-scope adjustments
        await db.revenue_adjustments.delete_many({"scope": "total"})
    return {"ok": True, "scope": payload.scope, "reset_at": now}


@api_router.get("/admin/stats")
async def admin_stats(_: User = Depends(require_admin)):
    total_orders = await db.orders.count_documents({})
    pending = await db.orders.count_documents({"status": "pending"})
    preparing = await db.orders.count_documents({"status": "preparing"})
    ready = await db.orders.count_documents({"status": "ready"})
    completed = await db.orders.count_documents({"status": "completed"})
    menu_count = await db.menu_items.count_documents({})

    resets = await _get_revenue_resets()
    start_of_day = datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0).isoformat()
    # Today revenue: max(start_of_day, today_reset_at)
    today_cutoff = start_of_day
    if resets.get("today_reset_at") and resets["today_reset_at"] > today_cutoff:
        today_cutoff = resets["today_reset_at"]

    pipeline = [
        {"$match": {"status": "completed", "created_at": {"$gte": today_cutoff}}},
        {"$group": {"_id": None, "total": {"$sum": "$total"}}},
    ]
    agg = await db.orders.aggregate(pipeline).to_list(1)
    today_revenue = (agg[0]["total"] if agg else 0) + await _sum_adjustments("today", since=today_cutoff)

    total_match = {"status": "completed"}
    if resets.get("total_reset_at"):
        total_match["created_at"] = {"$gte": resets["total_reset_at"]}
    pipeline_all = [
        {"$match": total_match},
        {"$group": {"_id": None, "total": {"$sum": "$total"}}},
    ]
    agg_all = await db.orders.aggregate(pipeline_all).to_list(1)
    total_revenue = (agg_all[0]["total"] if agg_all else 0) + await _sum_adjustments("total", since=resets.get("total_reset_at"))

    return {
        "total_orders": total_orders,
        "pending": pending,
        "preparing": preparing,
        "ready": ready,
        "completed": completed,
        "menu_count": menu_count,
        "today_revenue": today_revenue,
        "total_revenue": total_revenue,
        "today_reset_at": resets.get("today_reset_at"),
        "total_reset_at": resets.get("total_reset_at"),
    }


# ---------- Health ----------
@api_router.get("/")
async def root():
    return {"name": "The Crunchy Bite API", "status": "ok"}


# ---------- Startup: seed ----------
@app.on_event("startup")
async def seed_data():
    if await db.categories.count_documents({}) == 0:
        await db.categories.insert_many([dict(c) for c in CATEGORIES])
        logger.info("Seeded categories")
    if await db.menu_items.count_documents({}) == 0:
        items = []
        for raw in MENU_ITEMS:
            mi = MenuItem(**raw)
            items.append(mi.model_dump())
        await db.menu_items.insert_many(items)
        logger.info(f"Seeded {len(items)} menu items")


app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origin_regex=".*",
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()
